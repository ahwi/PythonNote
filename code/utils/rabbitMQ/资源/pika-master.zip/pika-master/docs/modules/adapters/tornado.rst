Tornado Connection Adapter
==========================
.. automodule:: pika.adapters.tornado_connection

Be sure to check out the :doc:`asynchronous examples </examples>` including the Tornado specific :doc:`consumer </examples/tornado_consumer>` example.

.. autoclass:: pika.adapters.tornado_connection.TornadoConnection
  :members:
  :inherited-members:
