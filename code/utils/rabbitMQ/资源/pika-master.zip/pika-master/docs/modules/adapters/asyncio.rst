asyncio Connection Adapter
==========================
.. automodule:: pika.adapters.asyncio_connection

Be sure to check out the :doc:`asynchronous examples </examples>` including the asyncio specific :doc:`consumer </examples/asyncio_consumer>` example.

.. autoclass:: pika.adapters.asyncio_connection.AsyncioConnection
  :members:
  :inherited-members:
